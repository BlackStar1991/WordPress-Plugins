jQuery(function ($) {
    $('#btn_update').click(function(){
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'updateDB',
                text: "this is test text", /// Тут так надо передавать значение в php переменную $text?
            },

            beforeSend: function( xhr ) {
                $('#btn_update').text('Обновление базы, сек...');
            },
            success: function( data ) {
                $('#btn_update').text('Отправить');
                alert( data );
            }
        });
    });
});

