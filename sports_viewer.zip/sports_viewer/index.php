<?php

// It's good day to die