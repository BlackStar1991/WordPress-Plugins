<?php


global $wpdb;
if( ! empty($wpdb->error) )
    wp_die( $wpdb->error );

$table_name = $wpdb->get_blog_prefix() . 'sports_viewer';


include_once ("uploadData.php");


if(array_key_exists('downloadHtml',$_POST)){
    purserHtml('create');
}



$tournaments = false;

?>
<h1 class="sv_title">SPORTS MANAGER</h1>
<div class="sv_wrapper">
    <?php
    if($tournaments){
        foreach ( $tournaments as $item){
            echo '<details class="fg_item">
                <div class="fg_item__wrapp">
                    <summary class="fg_tournament__title">'. $item->title .'</summary>
                    <form method="post"><input type="submit" name="uploadHtml" id="update" value="Update DB" /></form>
                </div>
                    <div class="fg_tournament__info">
                        <time class="fg_tournament__time">Last update: '. $item->object_last_modified .'</time>
                     </div>
                </details>';
        }
    } else{
        echo '<p>Tournaments are empty</p><button id="btn_update" class="btn_update">Update Sports Result</button>';
    } ?>
</div>



