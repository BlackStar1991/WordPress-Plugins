<?php

add_action( 'wp_ajax_updateDB', 'updateDataBase' );
function updateDataBase(){
    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'sports_viewer', // указываем таблицу
        array('json' => $_POST['text']),
        //array('object_last_modified' => 1 ),

        array( '%s' ),
        //array( '%d' )
    );

    wp_die();
}


