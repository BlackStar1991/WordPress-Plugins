<?php


if(!defined('WP_UNINSTALL_PLUGIN')){
    die;
}
/**
 * The database object.
 * @var wpdb
 */
global $wpdb;
$table_name = $wpdb->get_blog_prefix() . 'sports_viewer';
/// DELITE posttype
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
$wpdb -> query("DROP TABLE `btsports`. $table_name ");



die();