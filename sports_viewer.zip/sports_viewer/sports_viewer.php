<?php
/*
Plugin Name: Sports Viewer
Description:  WordPress tables about sports viewer
Version: 1.0.0
Author: BlackStar1991
Domain Path: /lang
*/

if (!defined('ABSPATH')) {
    die;
}


global $wpdb;

class sports_viewer
{


    public function register()
    {
        /// register ost type
        add_action('admin_menu', [$this, 'sports_viewerAddAdminPage']);

        /// enqueue scripts and styles for admin and frontPage
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_front']);

    }

    public function sports_viewerAddAdminPage()
    {
        add_menu_page(
            esc_html__("Sports Viewer Setting Page", 'sports_viewer'),
            esc_html__("Sports Viewer", 'sports_viewer'),
            'administrator',
            'sports_viewer',
            [$this, 'fg_options_page'],
            "dashicons-info",
            100
        );
    }


    /// after activation hook
    static function activation()
    {

        function create_table()
        {
            global $wpdb;
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';

            $table_name = $wpdb->get_blog_prefix() . 'sports_viewer';
            $charset_collate = $wpdb->get_charset_collate();

            if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {

                $sql = "CREATE TABLE {$table_name}
                ( json LONGTEXT NOT NULL COLLATE utf8_general_ci,
                  object_last_modified timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP)
                  {$charset_collate}";
                  dbDelta($sql);
            }

        }


        create_table();

        flush_rewrite_rules();
    }

    // after deactivation hook
    static function deactivation()
    {
        flush_rewrite_rules();
    }


    public function enqueue_admin()
    {
        wp_enqueue_style('SportsViewerStyleAdm', plugins_url('/assets/admin/styles.css', __FILE__));
        wp_enqueue_script('SportsViewerScriptAdm', plugins_url('/assets/admin/scripts.js', __FILE__), array('jquery'));
    }

    public function enqueue_front()
    {
        wp_enqueue_style('SportsViewerGuideStyle', plugins_url('/assets/front/styles.css', __FILE__));
    }


    /// Football Guide Admin HTML
    public function fg_options_page()
    {
        require_once plugin_dir_path(__FILE__) . 'admin/admin.php';
    }


}

if (class_exists('sports_viewer')) {
    $sports_viewer = new sports_viewer();
    $sports_viewer->register();
}


register_activation_hook(__FILE__, array($sports_viewer, 'activation'));
register_deactivation_hook(__FILE__, array($sports_viewer, 'deactivation'));




